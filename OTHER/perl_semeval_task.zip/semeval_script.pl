#!/usr/bin/perl -w
######################################################################
#
#	semeval_script.pl
#	Megan Davis
#	10/7/2017
#
#   Utilizing Code from: 
#      Text::NSP
# 	   Lingua::EN::Tagger
#   Text Used:   
#   BTMCINNES -- Stop List Txt
#   SCL-NMA -- http://saifmohammad.com/WebPages/NRC-Emotion-Lexicon.htm
#
#####################################################################
#	
#	How to Run:
#   1) Have semeval_script.pl, SCL-NMA.txt, and dev-full.txt
#	2) Run perl semeval_script.pl dev-full.txt SCL-NMA.txt 
#
#	ONLY TESTED ON WINDOWS 10  
#
#######################################################################
#
#
#	1)  Look at the sub routines to see detail -- will update this later
#

# USE 
use warnings;
use strict;
use Data::Dumper qw(Dumper);
use Lingua::EN::Tagger;

$Data::Dumper::Sortkeys = 1;



# Files: Currently utilizes two files dev-full.txt, SCL-NMA.txt
my $filename = $ARGV[0];
my $filename2 = $ARGV[1];

# Variables
my %OverallHash; #Hash containing all the data
my %SentimentHash;
my %Results;
my $num = 0; #Used assign a unique ID to hashes
my %bigram;
my $bigram_frequency = 0;


# Variables Not Being Used -- but still declaring to avoid run errors.
my $p = new Lingua::EN::Tagger;
my %unigram;
my $unigram_frequency = 0;


my $all_text;

#Open Dev-Full Text and read in the data/ preform text manipulations 
open(my $fh, '<', $filename) or die "Could not open";	
while(my $row = <$fh>)
{
	my @temparray = split('\t',$row);
	$OverallHash{$num}{ID} = $temparray[0];
	$OverallHash{$num}{Warrant0} = text_sanitation($temparray[1]);#$p->get_readable($p->add_tags($temparray[1]));
	$OverallHash{$num}{Warrant0_Sentiment} = 0;
	$OverallHash{$num}{Warrant1_Sentiment} = 0;
	$OverallHash{$num}{Warrant1} = text_sanitation($temparray[2]);#$p->get_readable($p->add_tags($temparray[2]));
	$OverallHash{$num}{CorrectLabel} = $temparray[3];
	$OverallHash{$num}{Reason_tagged} = $p->get_readable($p->add_tags($temparray[4]));
	$OverallHash{$num}{Reason_Claim_Combined} = text_sanitation($temparray[4] . " " .+ $temparray[5]);
	
	$OverallHash{$num}{Claim_Reason_Sentiment} = 0;
	$OverallHash{$num}{Claim_tagged} = $p->get_readable($p->add_tags($temparray[5]));
	$OverallHash{$num}{Debate_Title} = $temparray[6];
	$OverallHash{$num}{Debate_Info} = $temparray[7];
	$OverallHash{$num}{Answer} = -1;

	$all_text .= " " .$temparray[1];
	$all_text .= " " .$temparray[2];
	$all_text .= " " .$temparray[4];
	$all_text .= " " .$temparray[5];
	$all_text .= " " .$temparray[6];
	$all_text .= " " .$temparray[7];

	$num++;
}

#Reset Num
$num = 0;

## Open SCL-NMA Text file -- this has SO values for about 3000 words
open(my $fh, '<', $filename2) or die "Could not open";	
while(my $row = <$fh>)
{
	my @temparray = split('\t',$row);
	$SentimentHash{$num}{word} = $temparray[0];
	$SentimentHash{$num}{score} = $temparray[1];

	$num++;
}


calculate_warrant_sentiment_value();
warrant_sentiment_set();
COMAPRISION_SHOWDOWN();
accuracy();



#Calculating Sentiment Value
# 1) For each of the sentiment values for the Reason_Claim_Combined
# 2) Adds values together to determine if negative or positive overall
sub calculate_warrant_sentiment_value{
	#print "Beginning Sentiment Values\n";
	foreach my $t (keys %OverallHash)
	{
		foreach my $y (keys %SentimentHash) 
		{
			my $w = $SentimentHash{$y}{word};
			if($OverallHash{$t}{Reason_Claim_Combined} =~ /$w/)
			{
				$OverallHash{$t}{sentiment_value} += $SentimentHash{$y}{score};
			}

			if($OverallHash{$t}{Reason_Claim_Combined} =~ /$w/)
			{
				$OverallHash{$t}{sentiment_value} += $SentimentHash{$y}{score};		
			}
		}
	}
	#print "End Sentiment Values\n";
}



#Calculate Warrant Sentiment
# 1) For each of the warrants within a claim calculate the sentiment values
# 2) Adds values together to determine negative or positive overall
sub warrant_sentiment_set{
	#print "Beginning Sentiment Warrants\n";
	foreach my $x (keys %OverallHash)
	{
		foreach my $z (keys %SentimentHash) 
		{
			my $lt = $SentimentHash{$z}{word};
			#print "$t : $w\n";
			if($OverallHash{$x}{Warrant0} =~ /$lt/)
			{
				$OverallHash{$x}{Warrant0_Sentiment} += $SentimentHash{$z}{score};
			}

			if($OverallHash{$x}{Warrant1} =~ /$lt/)
			{
				$OverallHash{$x}{Warrant1_Sentiment} += $SentimentHash{$z}{score};	
			}
		}	
	}
}

#COMAPRISION SHOW DOWN
# 1) Calculate which warrant is closer to the claim_reason_sentiment
# 2) Assigns the answer to Hash for comparision
sub COMAPRISION_SHOWDOWN{
	#my $equal = 0;
	foreach my $yellow(keys %OverallHash)
	{
		my $Z1 = $OverallHash{$yellow}{Claim_Reason_Sentiment} - abs($OverallHash{$yellow}{Warrant0_Sentiment});
		$Z1 = abs($Z1);

		my $Z2 = $OverallHash{$yellow}{Claim_Reason_Sentiment} - abs($OverallHash{$yellow}{Warrant1_Sentiment});
		$Z2 = abs($Z2);

		#	print "$Z1 : $Z2\n";

		if($Z1 > $Z2)
		{
			$OverallHash{$yellow}{Answer} = '0';
		}	
		elsif ($Z2 > $Z1)
		{
			$OverallHash{$yellow}{Answer} = '1';
		}
		else
		{
			$OverallHash{$yellow}{Answer} = '-1';	
			#$equal++;
		}

	}
}


############# Sub Routines ######################

#Checks how many claims were accurately tagged (currently using randomness baseline) 
#-------------- Total Labels --------------
#Correct: 157 
#Total Labels: 317 
#Overall Accuracy: 49.5268138801262
sub accuracy{
	my $totalLabels = 0;
	my $correctTotalLabels = 0;
	foreach my $key (keys %OverallHash)
	{
		if($OverallHash{$key}{Answer} eq $OverallHash{$key}{CorrectLabel} )
		{
			$correctTotalLabels++;
		}

		$totalLabels++;
	}


	my $accuracy = ($correctTotalLabels / $totalLabels) * 100;

	print "-------------- Total Labels --------------\n";
	print "Correct: $correctTotalLabels \n";
	print "Total Labels: $totalLabels \n";
	print "Overall Accuracy: $accuracy";
}

#Prints out hash using Dumper
sub print_hash{
	#my %tempHash = $_[0];
	print "########################################\n";
	#print Dumper \%unigram;
	print "########################################\n";
	#print Dumper \%bigram;
	print "########################################\n";
	print Dumper \%OverallHash;
	print "########################################\n";
	#print Dumper \%SentimentHash;
}

sub create_bigram{
	my @words = split(/\s/, $all_text);
	for(my $i = 0; $i < $#words; $i++)
	{
		my $temp_text = $words[$i] . " " . $words[$i + 1];	
		if(!exists($bigram{$temp_text}))
		{
			$bigram{$temp_text} = 1;
		}
		else
		{
			$bigram{$temp_text}++;
		}
		$bigram_frequency++;		
	}
}

## Sanatizes Text
sub text_sanitation{
	my $my_text = $_[0];
	$my_text =~ s/[[:punct:]]//g;
	$my_text =~ s/\n+/\n/g;
	##############################################################################################
	######## Stop Words remove too much information for positive negative analysis ###############
	#my $t = stop_word_removal();
	#$my_text =~ s/$t//g;
	##############################################################################################
	$my_text =~ s/\s+/ /g;
	$my_text = lc($my_text);
	return $my_text;
}


################################################
#		NOT USED SUB ROUTINES
###############################################

#Creates a Unigram out of $all_text
sub create_unigram{
	my @words = split(/\s/, $all_text);
	for(my $i = 0; $i <= $#words; $i++)
	{
		if(!exists($unigram{$words[$i]}))
		{
			$unigram{$words[$i]} = 1;
		}
		else
		{
			$unigram{$words[$i]}++;
		}
		$unigram_frequency++;
	}
}


### THis bigram only pulls text that has certain tags -- Tag selection pulled from Thumbs Up Thumbs Down Paper
sub create_tagged_bigram{
	my @words = split(/\s/, $all_text);
	for(my $i = 0; $i < $#words; $i++)
	{
		my $temp_text = $words[$i] . " " . $words[$i + 1];	
		if($words[$i] =~ /(NN|NNS)/)
		{
			if($words[$i+1] =~ /JJ/)
			{
				if(!exists($bigram{$temp_text}))
				{
					$bigram{$temp_text} = 1;
				}
				else
				{
					$bigram{$temp_text}++;
				}
				$bigram_frequency++;
			}
		}
		elsif($words[$i] =~ /JJ/)
		{
			if($words[$i+1] =~ /(JJ|NNS|NN)/)
			{
				if(!exists($bigram{$temp_text}))
				{
					$bigram{$temp_text} = 1;
				}
				else
				{
					$bigram{$temp_text}++;
				}
				$bigram_frequency++;
			}
		}
	}
}

#Calculates PMI 
#Must create unigram first
#Pass in Word1 and Word2
sub pointwise_mutual_information{
	#info from unigram
	my $word1= shift;
	my $word2 = shift;
	#info from bigram
	my $co_occur = shift;
	
	$word1 = $word1 / $unigram_frequency;
	$word2 = $word2 / $unigram_frequency;

	$co_occur = $co_occur / $bigram_frequency;

	print "Word1 Prob: $word1 \n";
	print "Word2 Prob: $word2 \n";
	print "Co_Occur Prob: $co_occur \n";

	my $PMI = log($co_occur / ($word1 * $word2))/log(2);

	print "PMI: $PMI";
}

#Prints out Overall Hash -- missing some of the values, hasn't been updated
sub print_out_overall_hash{
	foreach my $key(keys %OverallHash)
	{
		print "------------------------";
		print "$OverallHash{$key}{ID} ~ ";
		print "$OverallHash{$key}{Debate_Title} ~ ";
		print "$OverallHash{$key}{Debate_Info} ~ ";
		print "$OverallHash{$key}{Warrant0} ~ ";
		print "$OverallHash{$key}{Warrant1} ~";
		print "$OverallHash{$key}{CorrectLabel} ~";
	}
}

#Uses rand to 'guess' the answers
sub random_sample{
	foreach my $key (keys %OverallHash)
	{
		my $tempRandom = rand();
		if($tempRandom > .5)
		{
			$OverallHash{$key}{Answer} = '1';
		}
		else
		{
			$OverallHash{$key}{Answer} = '0';
		}		
	}
}

#Calculate Semantic Orientation -- Empty Subroutine  
sub semantic_orientation{
	my $pmi_one = shift;
	my $pmi_two = shift;
}

###########################################################################
#  stoplist sub function -- FROM  Text::NSP
###########################################################################
sub stop_word_removal { 

    my $stop_regex = "";
    my $stop_mode = "AND";
    my $opt_stop = "stoplist-nsp.regex";

    open ( STP, $opt_stop ) ||
        die ("Couldn't open the stoplist file $opt_stop\n");
    
    while ( <STP> ) {
	chomp; 
	
	if(/\@stop.mode\s*=\s*(\w+)\s*$/) {
	   $stop_mode=$1;
	   	if(!($stop_mode=~/^(AND|and|OR|or)$/)) {
			print STDERR "Requested Stop Mode $1 is not supported.\n";
			exit;
	   	}
	   	next;
	} 
	
		# accepting Perl Regexs from Stopfile
		s/^\s+//;
		s/\s+$//;
	
		#handling a blank lines
		if(/^\s*$/) { next; }
	
	 	#check if a valid Perl Regex
    	if(!(/^\//)) {
	   		print STDERR "Stop token regular expression <$_> should start with '/'\n";
			exit;
        }
        if(!(/\/$/)) {
		   print STDERR "Stop token regular expression <$_> should end with '/'\n";
		   exit;
        }

        #remove the / s from beginning and end
    	s/^\///;
    	s/\/$//;
        
		#form a single big regex
    	$stop_regex.="(".$_.")|";
    }

    if(length($stop_regex)<=0) {
		print STDERR "No valid Perl Regular Experssion found in Stop file $opt_stop";
		exit;
    }
    
    chop $stop_regex;
    
    # making AND a default stop mode
    if(!defined $stop_mode) {
		$stop_mode="AND";
    }
    
    close STP;
    
    return $stop_regex; 
}
